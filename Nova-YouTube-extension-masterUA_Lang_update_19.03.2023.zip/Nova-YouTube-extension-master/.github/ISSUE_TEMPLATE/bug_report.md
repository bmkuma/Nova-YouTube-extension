---
name: Bug report
about: Create a report
title: '[Bug]'
labels: bug
assignees: ''

---

<!-- Note! Try updating/reinstalling the extensions. Maybe this will help. -->

*Describe the bug*

 - Browser: Chrome 999.0 <!-- The name and version of your browser -->
 - ...monkey 99.1 <!-- What userscript extension do you use: Tampermonkey, Violetmonkey, etc -->
 - Nova 6.6.1 <!-- script version -->
<!-- (optional) The url of the channel where my script fails to pause the Home video -->
